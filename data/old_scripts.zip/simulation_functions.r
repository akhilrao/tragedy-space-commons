#####
# Objective functions, continuation values, and functions to generate time paths from policy functions for a deterministic satellite-debris model of orbit use.
#####

# T-period approximation of planner's continuation value at every state on a grid (igrid) under a supplied policy mapping (X). The function implements policy iteration by propagating the policy and state variables from each state on the grid. The outer loop beginning line 20, where %do% is called, runs the propagation at each state in serial. The inner loop beginning line 26, where %dopar% is called, parallelizes the propagation from each state. (The state updates from t to t+1 are calculated for all elements of the (S,D) grid in parallel, then from t+1 to t+2, ...) Each propagation isn't very expensive, but can take multiple seconds per period with many states (e.g. 128x128=16384 states in the grid takes ~6 seconds per state update).
W_ih <- function(X,igrid,T,...) {
	Svals <- matrix(0,nrow=T,ncol=length(igrid$sats))
	Dvals <- matrix(0,nrow=T,ncol=length(igrid$debs))
	Xvals <- matrix(0,nrow=T,ncol=length(X))
	contval <- matrix(0,nrow=T,ncol=length(igrid$sats))

	sgl <- sqrt(dim(igrid)[1])				# "single_grid_length": assumes supplied grids are "square" (equal size in each dimension) and are stacked row-wise as columns

	Svals[1,] <- igrid$sats
	Dvals[1,] <- igrid$debs
	Xvals[1,] <- X
	contval[1,] <- one_p_return(Xvals[1,],Svals[1,])

	# Propagate states given policy from each (S,D) grid point
	contval <- foreach(i=2:T, .export=ls(), .combine=rbind, .inorder=TRUE) %do% {
		Svals[i,] <- S_(Xvals[i-1,],Svals[i-1,],Dvals[i-1,])
		Dvals[i,] <- D_(Xvals[i-1,],Svals[i-1,],Dvals[i-1,])
		next_state_raw <- c(Svals[i,],Dvals[i,])
		itm <- proc.time()[3]
		next_state <- cbind(next_state_raw[1:length(X)],next_state_raw[(length(X)+1):length(next_state_raw)])
		Xvals[i,] <- foreach(j=1:length(X), .export=ls(), .combine=cbind, .inorder=TRUE) %dopar% {
			interpolate(c(next_state[j],next_state[j+length(X)]),igrid,X)
		}
		il.time <- proc.time()[3] - itm
		#print(paste0("Finished period ",i, " inner loop. Time taken: ", round(il.time,3)," seconds."))		# uncomment to see how long each loop takes as it's running
		one_p_return(Xvals[i,],Svals[i,])*discount_fac^(i-1)
	}
	if(dim(contval)[1] < dim(Xvals)[1])  {contval <- rbind(one_p_return(Xvals[1,],Svals[1,]),contval)}
	contval[T,] <- fleet_ssval_T(Svals[T,],Dvals[T,],T)
	cv <- colSums(contval)
	return(cv)
}

# Planner's finite horizon value. Can be fed to a minimizer like optim() to return a finite-horizon time path.
fhvf <- function(X,S,D,T,...) {
	values <- matrix(0,nrow=(T+1),ncol=5)
	values[,1] <- seq(from=0,to=T,by=1)
	values[,2] <- X
	values[1,3] <- S
	values[1,4] <- D
	values[1,5] <- p*values[1,3] - F*values[1,2]

	for(j in 2:(T+1)) {
		values[j,3] <- S_(values[(j-1),2],values[(j-1),3],values[(j-1),4])
		values[j,4] <- D_(values[(j-1),2],values[(j-1),3],values[(j-1),4])
		values[j,5] <- one_p_return(values[j,2],values[j,3])*(discount_fac^(values[(j-1),1]))
	}
	values[is.na(values[,4]),4] <- max(values[!is.na(values[,4]),4])		# If debris growth runs away, reset it to the maximum value before it ran away
	values[(T+1),5] <- fleet_ssval_T(values[(T+1),3],values[(T+1),4],T+1)		# Make terminal period value into "steady state" value
	fleet_npv <- sum(values[,5])
	return(fleet_npv)
}

# Generate aT-period  time series from a given policy function (X), initial condition (S,D), and state grid (igrid). X is a length(igrid)xlength(igrid) matrix here.
seriesgen_pfn <- function(X,S,D,igrid,T,...) {
	values <- matrix(0,nrow=(T+1),ncol=7)
	values[,1] <- seq(from=0,to=T,by=1)
	values[1,3] <- S
	values[1,4] <- D
	policy <- X
	
	for(i in 2:(T+1)) {
		values[(i-1),2] <- interpolate( c(values[(i-1),3],values[(i-1),4]),igrid,policy)
		values[i,3] <- S_(values[(i-1),2],values[(i-1),3],values[(i-1),4])
		values[i,4] <- D_(values[(i-1),2],values[(i-1),3],values[(i-1),4])
		values[i,5] <- one_p_return(values[(i-1),2],values[i,3])*discount_fac^(i-1)
	}
	values[(T+1),2] <- interpolate(values[T,3],igrid,policy)
	values[(T+1),5] <- fleet_ssval_T(values[(T+1),3],values[(T+1),4],T+1)
	values[which(values[,4]=="NaN"),4] <- 1000000
	values[,6] <- V_ss(values[,3],values[,4])
	values[,7] <- L(S_(values[,2],values[,3],values[,4]),D_(values[,2],values[,3],values[,4]))
	values <- as.data.frame(values)
	colnames(values) <- c("time","launches","satellites","debris","fleet_pv","satellite_pv","collision_rate")
	return(values)
}

# Generate a T-period time series from a given launch time path (X) and initial condition (S,D). X is a Tx1 vector here.
seriesgen_ts <- function(X,S,D,T,...) {
	values <- matrix(0,nrow=(T+1),ncol=7)
	values[,1] <- seq(from=0,to=T,by=1)
	values[,2] <- X
	values[1,3] <- S
	values[1,4] <- D
	values[1,5] <- one_p_return(values[1,2],values[1,3])

	for(i in 2:(T+1)) {
		values[i,3] <- S_(values[(i-1),2],values[(i-1),3],values[(i-1),4])
		values[i,4] <- D_(values[(i-1),2],values[(i-1),3],values[(i-1),4])
		values[i,5] <- one_p_return(values[(i-1),2],values[i,3])
	}
	values[(T+1),5] <- fleet_ssval_T(values[(T+1),3],values[(T+1),4],T+1)
	values[which(values[,4]=="NaN"),4] <- 1000000
	values[,6] <- V_ss(values[,3],values[,4])
	values[,7] <- L(values[,3],values[,4])
	values <- as.data.frame(values)
	colnames(values) <- c("time","launches","satellites","debris","fleet_pv","satellite_pv","collision_rate")
	return(values)
}

# 2D interpolation function: interpolate the supplied values between the two grid points nearest the target in each dimension. Making this faster could speed up evaluation of W_ih quite a bit; the function gets called at every state, in every period. 
interpolate <- function(target,grid,values) {
	# calculate distances from target to grid nodes
	sgl <- sqrt(dim(grid)[1])				# "single_grid_length": assumes supplied grids are square and are stacked row-wise as columns
	## S grid
	S_node_distances <- abs(target[1]-grid$sats)
	S_nearest_nodes <- sort(S_node_distances,index.return=TRUE)$ix[seq(1,2*sgl)]
	## D_grid
	D_node_distances <- abs(target[2]-grid$debs)
	D_nearest_nodes <- sort(D_node_distances,index.return=TRUE)$ix[seq(1,2*sgl)]
	
	# locate nearest S and D
	nearest_S_dist <- S_node_distances[c(S_nearest_nodes[1],S_nearest_nodes[sgl+1])]
	nearest_D_dist <- D_node_distances[c(D_nearest_nodes[1],D_nearest_nodes[sgl+1])]
	
	# weight nearby node higher than farther node
	S_node_wts <- c(0,0)
	D_node_wts <- c(0,0)
	S_node_wts[1] <- nearest_S_dist[2]/(nearest_S_dist[1]+nearest_S_dist[2])
	S_node_wts[2] <- nearest_S_dist[1]/(nearest_S_dist[1]+nearest_S_dist[2])
	D_node_wts[1] <- nearest_D_dist[2]/(nearest_D_dist[1]+nearest_D_dist[2])
	D_node_wts[2] <- nearest_D_dist[1]/(nearest_D_dist[1]+nearest_D_dist[2])
	
	# interpolate
	nearby_values <- values[intersect(S_nearest_nodes,D_nearest_nodes)]
	S_comp_1 <- S_node_wts[1]*nearby_values[1] + S_node_wts[2]*nearby_values[3]
	S_comp_2 <- S_node_wts[1]*nearby_values[2] + S_node_wts[2]*nearby_values[4]
	interpolation <- D_node_wts[1]*S_comp_1 + D_node_wts[2]*S_comp_2

	return(interpolation)
}

# Profit function with continuation value lookup/interpolation. This is used to generate a policy in the value function iteration algorithm.
profit <- function(X,igrid,entry_no,value_fn,...) {
	S <- igrid$sats[entry_no]
	D <- igrid$debs[entry_no]
	S_next <- S_(X,S,D)
	D_next <- D_(X,S,D)
	next_state <- c(S_next,D_next)
	interpolation <- interpolate(next_state,igrid,value_fn)
	prof <- one_p_return(X,S) + discount_fac*interpolation
	return(prof)
}
