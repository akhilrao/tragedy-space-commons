#####
# Script to calculate open access and optimal: (1) policy and value functions; (2) time paths.
#####
rm(list=ls())
library(ggplot2)
library(viridis)
library(gridExtra)
library(doParallel)
library(compiler)
library(plot3D)
source("equations.r")
source("simulation_functions.r")
source("simulation_algorithms.r")
system(sprintf("taskset -p 0xffffffff %d", Sys.getpid())) # Adjusts the R session's affinity mask from 1 to f, allowing the R process to use all cores.

enableJIT(3) # JIT compilation speeds up some evaluations a little.

############### Set "ncores" to the number of cores you can spare for this script.
ncores <- 1
### Grid bounds and size. gridlength=25 (=> 25x25 = 625 states) may be a reasonable size for a laptop with 2-4 cores to spare.
gridmin <- 0
gridmax <- 10
gridlength <- 25

############### Set parameters and build grid
### economics
p <- 1
F <- 5
r_s <- p/F
discount_fac <- 0.99
r <- (1 - discount_fac)/discount_fac 
fe_eqm <- r_s - r

### physics/engineering
d <- 0.5
m <- 3

#### negexp rate parameters
aSS <- 0.05
aSD <- 0.05
aDD <- 0.025 
bSS <- 10
bSD <- 5.375
bDD <- 0.9

#### statmech rate parameters - still testing
# aSS <- 0.0000001
# aSD <- 0.005
# aDD <- 0.000001
# bSS <- 100
# bSD <- 75
# bDD <- 5

#### build grid

# ##### evenly spaced grid
# base_piece <- seq(from=gridmin, to=gridmax, length.out=gridlength)
# sats <- rep(base_piece,times=gridlength)
# debs <- sort(base_piece,times=gridlength))
# igrid <- as.data.frame(cbind(sats,debs))

##### grid with more points near zero - supposed to reduce approximation error where there is more curvature.
base_piece <- (seq(from=gridmin, to=gridmax^0.1, length.out=gridlength))^10
sats <- rep(base_piece,times=gridlength)
debs <- sort(rep(base_piece,times=gridlength))
igrid <- as.data.frame(cbind(sats,debs))


############### Solve for open access policy
open_access <- oapolicy(igrid,ncores)

oa_fv_mat <- t(matrix(open_access$fleet_value,nrow=gridlength))
oa_po_mat <- t(matrix(open_access$launches,nrow=gridlength))

dev.new()
par(mfrow=c(1,2))
image2D(z=oa_fv_mat,x=base_piece,y=base_piece,xlab=c("Debris"),ylab=c("Satellites"),col=magma(n=100),main="Open access fleet value")
image2D(z=oa_po_mat,x=base_piece,y=base_piece,xlab=c("Debris"),ylab=c("Satellites"),col=magma(n=100), main="Open access launch policy")


############### Generate a guess of the optimal policy and value functions using fpts_vfsolve()
numerical_fleet_planner <- as.data.frame(fpts_vfsolve(igrid,150,ncores=ncores))

nfp_fv_mat <- t(matrix(numerical_fleet_planner$fleet_value,nrow=gridlength))
nfp_po_mat <- t(matrix(numerical_fleet_planner$launches,nrow=gridlength))

dev.new()
par(mfrow=c(1,2))
image2D(z=nfp_fv_mat,x=base_piece,y=base_piece,xlab=c("Debris"),ylab=c("Satellites"),col=magma(n=100),main="Optimal fleet value")
image2D(z=nfp_po_mat,x=base_piece,y=base_piece,xlab=c("Debris"),ylab=c("Satellites"),col=magma(n=100), main="Optimal launch policy")

# TODO: learn nfp on smaller grid, project onto igrid to get guess


############### Use vfi_solver() to approximate the optimal policy and value functions
dev.new()
### A "better" guess
pguess <- numerical_fleet_planner$launches
vguess <- numerical_fleet_planner$fleet_value
### Not the worst guess ever
#pguess <- as.vector(rep(0,length.out=gridlength ))
#vguess <- igrid$sats

#piter_schedule <- c(3,10,25,50,75,100,10) # use with a less-good guess, since the first iterations get it warmed up
piter_schedule <- c(125,0,200,0,200,0,0) # use with a better guess, since the first iterations expect something decent

### Run vfi_solver(). 
fleet_planner <- suppressWarnings(vfi_solver(igrid,vguess,pguess,piter_schedule,ncores))

fp_fv_mat <- t(matrix(fleet_planner$fleet_value,nrow=gridlength))
fp_po_mat <- t(matrix(fleet_planner$launches,nrow=gridlength))

dev.new()
par(mfrow=c(2,2))
image2D(z=oa_fv_mat,x=base_piece,y=base_piece,xlab=c("Debris"),ylab=c("Satellites"),col=magma(n=100),main="Open access fleet value")
image2D(z=oa_po_mat,x=base_piece,y=base_piece,xlab=c("Debris"),ylab=c("Satellites"),col=magma(n=100), main="Open access launch policy")
image2D(z=fp_fv_mat,x=base_piece,y=base_piece,xlab=c("Debris"),ylab=c("Satellites"),col=magma(n=100),main="Optimal fleet value")
image2D(z=fp_po_mat,x=base_piece,y=base_piece,xlab=c("Debris"),ylab=c("Satellites"),col=magma(n=100), main="Optimal launch policy")


#### Compare open access and planner time paths
dfrm <- merge(open_access,fleet_planner,by=c("satellites"),suffix=c(".oa",".fp"))
planner_series <- as.data.frame(seriesgen_pfn(fleet_planner$optimal_launch_pfn,0,0,igrid,100))
oa_series <- as.data.frame(seriesgen_pfn(open_access$launches,0,0,igrid,100))

launch_seriescomp <- ggplot() + 
				geom_line(data=oa_series,aes(x=time,y=launches),size=1.2) +
				geom_line(data=planner_series,aes(x=time,y=launches),linetype="dashed",size=1.2) +
				ylab("Launch rate path") + xlab("") +
				ylim(min(oa_series$launches,planner_series$launches),max(oa_series$launches,planner_series$launches)) + theme_minimal() + scale_color_viridis()
sats_seriescomp <- ggplot() + 
				geom_line(data=oa_series,aes(x=time,y=satellites),size=1.2) +
				geom_line(data=planner_series,aes(x=time,y=satellites),linetype="dashed",size=1.2) +
				ylab("Satellite stock path") + xlab("Time") +
				ylim(min(oa_series$satellites,planner_series$satellites),max(oa_series$satellites,planner_series$satellites)) + theme_minimal() + scale_color_viridis()
debs_seriescomp <- ggplot() + 
				geom_line(data=oa_series,aes(x=time,y=debris),size=1.2) +
				geom_line(data=planner_series,aes(x=time,y=debris),linetype="dashed",size=1.2) +
				ylab("Debris stock path") + xlab("Time") +
				ylim(min(oa_series$satellites,planner_series$satellites),max(oa_series$satellites,planner_series$satellites)) + theme_minimal() + scale_color_viridis()
collrate_seriescomp <- ggplot() + 
				geom_line(data=oa_series,aes(x=time,y=collision_rate),size=1.2) +
				geom_line(data=planner_series,aes(x=time,y=collision_rate),linetype="dashed",size=1.2) +
				ylab("Collision rate path") + xlab("Time") +
				ylim(min(oa_series$satellites,planner_series$satellites),max(oa_series$satellites,planner_series$satellites)) + theme_minimal() + scale_color_viridis()

dev.new()		
grid.arrange(launch_seriescomp,sats_seriescomp,collrate_seriescomp,debs_seriescomp,ncol=2)


########
# Generate time series
########

oa_path <- oa_tsgen(0,0,100,fe_eqm)
planner_path <- fp_tsgen(0,0,250)
two_paths <- merge(oa_path,planner_path,by=c("time"),suffixes=c(".oa",".fp"))

launch_path_comp <- ggplot(data=two_paths[1:100,]) + 
					geom_line(aes(x=time,y=launches.oa),size=1) + 
					geom_line(aes(x=time,y=launches.fp),size=1.25,color="blue") +
					theme_minimal() + xlab("Time") + ylab("Launches")
sat_path_comp <- ggplot(data=two_paths[1:100,]) + 
					geom_line(aes(x=time,y=satellites.oa),size=1) + 
					geom_line(aes(x=time,y=satellites.fp),size=1.25,color="blue") +
					theme_minimal() + xlab("Time") + ylab("Satellites")
deb_path_comp <- ggplot(data=two_paths[1:100,]) + 
					geom_line(aes(x=time,y=debris.oa),size=1) + 
					geom_line(aes(x=time,y=debris.fp),size=1.25,color="blue") +
					theme_minimal() + xlab("Time") + ylab("Debris")
fleet_val_comp <-ggplot(data=two_paths[1:100,]) + 
					geom_line(aes(x=time,y=fleet_pv.oa),size=1) + 
					geom_line(aes(x=time,y=fleet_pv.fp),size=1.25,color="blue") +
					theme_minimal() + xlab("Time") + ylab("Fleet NPV")
sat_val_comp <-ggplot(data=two_paths[1:100,]) + 
					geom_line(aes(x=time,y=satellite_pv.oa),size=1) + 
					geom_line(aes(x=time,y=satellite_pv.fp),size=1.25,color="blue") +
					theme_minimal() + xlab("Time") + ylab("Satellite PV")
coll_rate_comp <-ggplot(data=two_paths[1:100,]) + 
					geom_line(aes(x=time,y=collision_rate.oa),size=1) + 
					geom_line(aes(x=time,y=collision_rate.fp),size=1.25,color="blue") +
					#geom_line(aes(x=time,y=fe_eqm),linetype="dashed",color="red") + 
					theme_minimal() + xlab("Time") + ylab("Expected collision rate")

dev.new()
grid.arrange(sat_val_comp,fleet_val_comp,coll_rate_comp,launch_path_comp,sat_path_comp,deb_path_comp,ncol=3)


########
# Compare policy-interpolated planner series, with time-solved planner series
########

launch_path_comp2 <- ggplot() + 
					geom_line(data=planner_path[1:100,],aes(x=time,y=launches),size=1.25) + 
					geom_line(data=planner_series,aes(x=time,y=launches),size=1.1,color="blue") +
					theme_minimal() + xlab("Time") + ylab("Launches")
sat_path_comp2 <- ggplot() + 
					geom_line(data=planner_path[1:100,],aes(x=time,y=satellites),size=1.25) + 
					geom_line(data=planner_series,aes(x=time,y=satellites),size=1.1,color="blue") +
					theme_minimal() + xlab("Time") + ylab("Satellites")
deb_path_comp2 <- ggplot() + 
					geom_line(data=planner_path[1:100,],aes(x=time,y=debris),size=1.25) + 
					geom_line(data=planner_series,aes(x=time,y=debris),size=1.1,color="blue") +
					theme_minimal() + xlab("Time") + ylab("Debris")
fleet_val_comp2 <-ggplot() + 
					geom_line(data=planner_path[1:100,],aes(x=time,y=fleet_pv),size=1.25) + 
					geom_line(data=planner_series,aes(x=time,y=fleet_pv),size=1.1,color="blue") +
					theme_minimal() + xlab("Time") + ylab("Fleet NPV")
sat_val_comp2 <-ggplot() + 
					geom_line(data=planner_path[1:100,],aes(x=time,y=satellite_pv),size=1.25) + 
					geom_line(data=planner_series,aes(x=time,y=satellite_pv),size=1.1,color="blue") +
					theme_minimal() + xlab("Time") + ylab("Satellite PV")
coll_rate_comp2 <-ggplot() + 
					geom_line(data=planner_path[1:100,],aes(x=time,y=collision_rate),size=1.25) + 
					geom_line(data=planner_series,aes(x=time,y=collision_rate),size=1.1,color="blue") +
					#geom_line(aes(x=time,y=fe_eqm),linetype="dashed",color="maroon") + 
					theme_minimal() + xlab("Time") + ylab("Expected collision rate")

dev.new()
grid.arrange(sat_val_comp2,fleet_val_comp2,coll_rate_comp2,launch_path_comp2,sat_path_comp2,deb_path_comp2,ncol=3)
