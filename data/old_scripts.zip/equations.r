#####
# Equations for a deterministic satellite-debris model of orbit use
#####

# Rate of satellite-destroying collisions
L <- function(S,D,...) {
	1 - exp(-aSS*S-aSD*D)			# A smooth function over [0,\inf). Globally and jointly concave, and doesn't satisfy "zero if there are no satellites" (L(0,D) != 0). Referred to as "negexp rate".
	#pmin(aSS*S^2+aSD*S*D,1)		# A function with a corner somewhere in S and D. Convex up to that corner, then flat after. Globally jointly convex in S and D. Satisfies "zero if there are no satellites" (L(0,D) = 0). Referred to as "statmech rate".
}

# Number of new fragments created 
G <- function(S,D,...) {
	sat_caused <- ifelse( (S+D)>0, L(S,D)*(S/(S+D)), 0)
	deb_caused <- ifelse( (S+D)>0, L(S,D)*(D/(S+D)), 0)
	newfrags <- bSS*sat_caused*S + bSD*deb_caused*S + bDD*(1 - exp(-aDD*D))*D 		# Use with negexp rate
	#newfrags <- bSS*sat_caused*S + bSD*deb_caused*S + bDD*aDD*D^2		# Use with statmech rate
	return(newfrags)
}

# Satellite law of motion 
S_ <- function(X,S,D,...) {
	(1 - L(S,D))*S + X
}

# Debris law of motion
D_ <- function(X,S,D,...) {
	stock <- D*(1-d) + G(S,D) + m*X
	stock[is.na(stock)] <- max(stock[!is.na(stock)]) 		# If debris growth runs away, reset it to the maximum value before it ran away
	stock
}

# Fleet returns
one_p_return <- function(X,S,...) {
	p*S - F*X
}

# Infinite horizon satellite value
V_ss <- function(S,D,...) {
	p/(1-discount_fac*(1-L(S,D)))
}

# open access equilibrium condition
eqmcond <- function(X,S,D,fe_eqm,...) {
	L(S_(X,S,D),D_(X,S,D)) - fe_eqm
}

# Function to calculate the MEC path from an open access path and a planner's path. MEC is calculated as the difference in the loss rates. oa_xsd and fp_xsd are Tx3 matrices of (X_t, S_t, D_t).
mec <- function(oa_xsd,fp_xsd) {
	oa_loss <- L(S_(oa_xsd[,1],oa_xsd[,2],oa_xsd[,3]),D_(oa_xsd[,1],oa_xsd[,2],oa_xsd[,3]))
	fp_loss <- L(S_(fp_xsd[,1],fp_xsd[,2],fp_xsd[,3]),D_(fp_xsd[,1],fp_xsd[,2],fp_xsd[,3]))
	mec <- oa_loss - fp_loss
	return(mec)
}

# terminal period fleet steady state value
fleet_ssval_T <- function(S,D,T,...) {
	value <- ((discount_fac^T)/(1-discount_fac))*one_p_return(L(S,D)*S,S)
	return(value)
} 
