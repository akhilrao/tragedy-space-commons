#####
# Algorithms to generate open access and optimal time paths and policy functions for a deterministic satellite-debris model of orbit use.
#####

library(rootSolve)


############### Open access

### Algorithm to calculate an open access launch policy function. Evaluates the equilibrium condition "eqmcond" from equations.r at every (S,D) grid point given by igrid.
oapolicy <- function(igrid,ncores,...) {
ptm <- proc.time()
	launches <- rep(0,length=dim(igrid)[1])

	for(j in 1:length(igrid)) {
		X <- uniroot.all(eqmcond,c(0,10),S=igrid$sats[j],D=igrid$debs[j],fe_eqm=fe_eqm)
		if(length(X)==0) { launches[j] <- 0 }	
		if(length(X)>0) { launches[j] <- X }
	}

	launches[which(launches=="Inf")] <- -1
	fleet_size <- S_(launches,igrid$sats,igrid$debs)
	ih_sat_value <- V_ss(S_(launches,igrid$sats,igrid$debs),igrid$debs)
	
	registerDoParallel(cores=ncores)
	ih_fleet_value <- W_ih(X=launches,igrid=igrid,T=200)
	stopImplicitCluster()

	loss <- L(S_(launches,igrid$sats,igrid$debs),igrid$debs)
	satellite_oc <- rep(F*(1+r),length=length(launches))
	results <- as.data.frame(cbind(igrid,launches,fleet_size,loss,ih_sat_value,satellite_oc,ih_fleet_value))
	colnames(results) <- c("satellites","debris","launches","fleet_size","loss_next","satellite_value","satellite_opportunity_cost","fleet_value")
	write.csv(results,file="./oa.policy.csv")
	print(paste("Total time taken for open access policy: ",round(((proc.time() - ptm)[3])/60,4)," minutes",sep=""))
	return(results)
}


# Algorithm to calculate an open access finite-horizon time series.
oa_tsgen <- function(S,D,T,fe_eqm,...) {
	ctm <- proc.time()[3]
	launch_path <- rep(0,length=(T+1))
	sat_path <- rep(S,length=(T+1))
	deb_path <- rep(D,length=(T+1))
	fleet_pv_path <- rep(0,length=(T+1))
	for(t in 1:T ) {
		X <- uniroot.all(eqmcond,c(0,100000),S=sat_path[t],D=D,fe_eqm=fe_eqm)
		if(length(X)==0) { launch_path[t] <- 0 }	
		if(length(X)>0) { launch_path[t] <- X }
		sat_path[t+1] <- S_(launch_path[t],sat_path[t],deb_path[t])
		deb_path[t+1] <- D_(launch_path[t],sat_path[t],deb_path[t])
		fleet_pv_path[t] <- one_p_return(launch_path[t],sat_path[t])*discount_fac^(t-1)
	}
	fleet_pv_path[T+1] <- fleet_ssval_T(sat_path[T],deb_path[T],T)
	clock <- proc.time()[3] - ctm

	time_series <- data.frame(time=seq(0,T),launches=launch_path,satellites=sat_path,debris=deb_path,fleet_pv=fleet_pv_path,satellite_pv=V_ss(launch_path,sat_path),collision_rate=L(sat_path,deb_path))

	print("Open access time series generated.") 
	print(paste0("Time to compute launch path and propagate stocks: ", clock, " seconds."))

	return(time_series)
}

############### Fleet planner

### Algorithm to calculate the planner's optimal launch policy function. Alternates between value function and policy function iteration, as determined by piter.schedule and the schedule described in lines 128-202. Requires an initial guess of the fleet value function (vguess), the launch policy function (pguess). Both value and policy function iteration steps are parallelized across (ncores) cores.
vfi_solver <- function(grid,vguess,pguess,piter.schedule,ncores,...) {
	# initialize empty matrix for panel
	pancols <- 4
	panrows <- dim(igrid)[1]
	panel <- data.frame(matrix(0,nrow=panrows,ncol=pancols))
	colnames(panel)[1:4] <- c("V","S","D","X")

	# satellite-debris grids for panel
	gridstart <- min(igrid)
	gridend <- max(igrid)
	#gridspace <- abs(igrid$sats[1]-igrid$sats[2])	 # this is fine for evenly-spaced grids
	gridspace <- mean(diff(igrid$sats))		# this is better for unevenly-spaced grids
	panel$S <- igrid$sats
	panel$D <- igrid$debs

	panel$X <- as.vector(pguess)
	panel$V <- as.vector(vguess)

	newX <- rep(-1,length=panrows)
	result <- cbind(newX,newX,newX)

	# initialize distance-time matrix, epsilon-delta, and count
	distmat <- data.frame(matrix(-1,nrow=10000,ncol=5))
	colnames(distmat) <- c("distance","maximization.time","policyiter.time","write.time","total.time")
	epsilon <- 2*gridspace
	delta <- epsilon + 10
	delta2 <- delta
	count <- 0
	cat(paste("\n Stopping criteria: distance < ", epsilon, "\n", sep=""))

	v_max <- max(vguess)
	v_min <- min(vguess)
	true_v_max <- v_max
	true_v_min <- v_min
	p_max <- max(pguess)
	p_min <- min(pguess)

	valueplot <- ggplot(data=panel) + 
				geom_contour(aes(x=D,y=S,z=V,colour=..level..),linejoin="round") + 
				theme_minimal() + 
				theme(axis.text=element_text(size=15),axis.title=element_text(size=15,face="bold")) + 
  				scale_colour_viridis(name = "Fleet \n value")

	policyplot <- ggplot(data=panel) + 
				geom_contour(aes(x=D,y=S,z=X,colour=..level..),linejoin="round") + 
				theme_minimal() + 
				theme(axis.text=element_text(size=15),axis.title=element_text(size=15,face="bold")) + 
  				scale_colour_viridis(name = "Launch \n rate")
	grid.arrange(valueplot,policyplot,ncol=2)
	
	# create cluster to parallelize maximization step
	registerDoParallel(cores=ncores)

	## average value of initial guess - value function should be at least this good
	benchmarkval <- mean(panel$V)

	# solver loop
	while(delta > epsilon && delta2 > 0.5*epsilon) {
		## plot current value function
		valueplot <- ggplot(data=panel) + 
				geom_contour(aes(x=D,y=S,z=V,colour=..level..),linejoin="round") + 
				theme_minimal() + 
				theme(axis.text=element_text(size=15),axis.title=element_text(size=15,face="bold")) + 
  				scale_colour_viridis(name = "Fleet \n value")

		policyplot <- ggplot(data=panel) + 
				geom_contour(aes(x=D,y=S,z=X,colour=..level..),linejoin="round") + 
				theme_minimal() + 
				theme(axis.text=element_text(size=15),axis.title=element_text(size=15,face="bold")) + 
  				scale_colour_viridis(name = "Launch \n rate")

		t.tm <- proc.time()
		## maximization step
		cat(paste0("\n Starting maximization step... "))
		m.tm <- proc.time()
		result <- foreach(k=1:panrows, .export=ls(), .combine=rbind, .inorder=TRUE) %dopar% {
			ctm <- proc.time()[3]
			solution <- optim(par=panel$X[k], fn=profit, igrid=igrid, entry_no=k, value_fn=panel$V, control=list(fnscale=-1), method="L-BFGS-B", lower=0, upper=100)
			argmax <- solution$par
			vfn <- solution$value
			clock <- proc.time()[3] - ctm
			result <- c(argmax,vfn,clock)
			return(result)
		}
		maxim.time <- (proc.time()-m.tm)[3]
		newX <- result[,1]
		avg_cell_time <- mean(result[,3])
		cat(paste0("Finished. \n Average cell time: ",round(avg_cell_time,3)," seconds\n"))
		rownames(newX) <- NULL

		## update panel with new policy
		panel$X <- newX
		newV <- result[,2]
		
		cat(paste0("\n Starting propagation step... "))
		avg_period_time <- proc.time()[3]
		## calculate new value function - expectation/propagation step
		if(0 <= count&&count < 3) {
			policy.iteration.steps <- piter.schedule[1]
			if(piter.schedule[1]==0) {policyiter.time <- 0}
			if(piter.schedule[1]!=0) {
				pit.tm <- proc.time()[3]
				policy.iteration.steps <- piter.schedule[1]
				newV <- W_ih(newX,igrid,policy.iteration.steps) 
				policyiter.time <- proc.time()[3] - pit.tm
			}
		}
		if(3 <= count&&count < 8) {
			pit.tm <- proc.time()[3]
			if(piter.schedule[2]==0) {policyiter.time <- 0}
			if(piter.schedule[2]!=0) {
				pit.tm <- proc.time()[3]
				policy.iteration.steps <- piter.schedule[2]
				newV <- W_ih(newX,igrid,policy.iteration.steps) 
				policyiter.time <- proc.time()[3] - pit.tm
			}
		}
		if(8 <= count&&count < 15) {
			pit.tm <- proc.time()[3]
			if(piter.schedule[3]==0) {policyiter.time <- 0}
			if(piter.schedule[3]!=0) {
				pit.tm <- proc.time()[3]
				policy.iteration.steps <- piter.schedule[3]
				newV <- W_ih(newX,igrid,policy.iteration.steps) 
				policyiter.time <- proc.time()[3] - pit.tm
			}
		}
		if(15 <= count&&count < 20) {
			pit.tm <- proc.time()[3]
			if(piter.schedule[4]==0) {policyiter.time <- 0}
			if(piter.schedule[4]!=0) {
				pit.tm <- proc.time()[3]
				policy.iteration.steps <- piter.schedule[4]
				newV <- W_ih(newX,igrid,policy.iteration.steps) 
				policyiter.time <- proc.time()[3] - pit.tm
			}
		}
		if(20 <= count&&count < 30) {
			pit.tm <- proc.time()[3]
			if(piter.schedule[5]==0) {policyiter.time <- 0}
			if(piter.schedule[5]!=0) {
				pit.tm <- proc.time()[3]
				policy.iteration.steps <- piter.schedule[5]
				newV <- W_ih(newX,igrid,policy.iteration.steps) 
				policyiter.time <- proc.time()[3] - pit.tm
			}
		}
		if(30 <= count&&count < 40) {
			pit.tm <- proc.time()[3]
			if(piter.schedule[6]==0) {policyiter.time <- 0}
			if(piter.schedule[6]!=0) {
				pit.tm <- proc.time()[3]
				policy.iteration.steps <- piter.schedule[6]
				newV <- W_ih(newX,igrid,policy.iteration.steps) 
				policyiter.time <- proc.time()[3] - pit.tm
			}
		}
		if(40 <= count) {
			pit.tm <- proc.time()[3]
			if(piter.schedule[7]==0) {policyiter.time <- 0}
			if(piter.schedule[7]!=0) {
				pit.tm <- proc.time()[3]
				policy.iteration.steps <- piter.schedule[7]
				newV <- W_ih(newX,igrid,policy.iteration.steps) 
				policyiter.time <- proc.time()[3] - pit.tm
			}
		}
		avg_period_time <- ifelse(policy.iteration.steps>0, (proc.time()[3] - avg_period_time)/policy.iteration.steps, 0)
		cat(paste0("Finished. \n Average period time: ",round(avg_period_time,3)," seconds\n"))

		## update count
		count <- count+1
		## calculate |V-newV| and |delta[i] - delta[i-1]|
		delta <- max(abs((panel$V-newV))) #infinity norm of distance between the value vectors
		#delta <- sqrt(sum((panel$V-newV)^2)) #l2 norm of distance between the value vectors
		if(count>1) {delta2 <- abs(distmat$distance[count]-distmat$distance[(count-1)])}
		## update value function
		panel$V <- newV
		v_min_new <- min(panel$V)
		v_max_new <- max(panel$V)
		true_v_min <- min(true_v_min,min(v_min_new,v_min))
		true_v_max <- max(true_v_max,max(v_max_new,v_max))

		## plot new value function
		newvalueplot <- ggplot(data=panel) + 
				geom_contour(aes(x=D,y=S,z=V,colour=..level..),linejoin="round") + 
				theme_minimal() + 
				theme(axis.text=element_text(size=15),axis.title=element_text(size=15,face="bold")) + 
  				scale_colour_viridis(name = "Fleet \n value")

		newpolicyplot <- ggplot(data=panel) + 
				geom_contour(aes(x=D,y=S,z=X,colour=..level..),linejoin="round") + 
				theme_minimal() + 
				theme(axis.text=element_text(size=15),axis.title=element_text(size=15,face="bold")) + 
  				scale_colour_viridis(name = "Launch \n rate")

		grid.arrange(valueplot,policyplot,newvalueplot,newpolicyplot,ncol=2)

		## write out to csv
		wr.tm <- proc.time()
		valuemat <- matrix(panel$V,nrow=sqrt(dim(igrid)[1]),ncol=sqrt(dim(igrid)[1]),byrow=TRUE)
		policymat <- matrix(panel$X,nrow=sqrt(dim(igrid)[1]),ncol=sqrt(dim(igrid)[1]),byrow=TRUE)
		write.csv(valuemat,file="vfi_vfn.csv")
		write.csv(policymat,file="vfi_pfn.csv")
		write.time <- (proc.time() - wr.tm)[3]
		## calculate total time
		tot.time <- (proc.time() - t.tm)[3]
		## fill distance-time matrix
		distmat[count,] <- c(delta,maxim.time,policyiter.time,write.time,tot.time)
		## out
		cat(paste("\n Finished iteration ", count,", distance is ", delta, sep=""))
	}

	cat(paste(
		"\n Total maximization time: ", sum(distmat$maximization.time[which(distmat$maximization.time>0)]),
		"\n Total policy iteration time: ", sum(distmat$policyiter.time[which(distmat$policyiter.time>0)]),
		",\n Total CSV write time: ", sum(distmat$write.time[which(distmat$write.time>0)]),
		",\n Total algorithm time: ", sum(distmat$total.time[which(distmat$total.time>0)]), 
		",\n Final distance: ", delta, 
		",\n Total number of iterations: ", count, 
		",\n Average time per iteration: ", (sum(distmat$total.time[which(distmat$total.time>0)]))/count,"\n\n", sep=""))

	stopImplicitCluster()

	return(as.data.frame(cbind(satellites=panel$S,debris=panel$D,optimal_fleet_vfn=panel$V,optimal_launch_pfn=panel$X,optimal_fleet_size=S_(panel$X,panel$S,panel$D),optimal_sat_val=V_ss(S_(panel$X,panel$S,panel$D),panel$S,panel$D))))
}

# An algorithm to approximate the planner's infinite-horizon policy and value functions by computing finite-horizon policies and values at each point in a grid. Evaluation is parallelized across (ncores) cores. The output can be used as a guess for vfi_solver(), or as an approximate policy/value by itself.
fpts_vfsolve <- function(igrid,T,ncores,...) {
	registerDoParallel(cores=ncores)

	policy_value <- as.data.frame(matrix(-1,nrow=dim(igrid)[1],ncol=6))

	print("Generating finite-horizon guess...")
	policy_value <- foreach(j=1:dim(igrid)[1], .export=ls(), .combine=rbind, .inorder=TRUE) %dopar% {
		ctm <- proc.time()[3]
		parms <- c(rep(0.01,length=T),0,igrid$sats[j],igrid$debs[j])
		solution <- optim(par=parms[1:(T+1)],fn=fhvf, S=parms[(T+2)], D=parms[(T+3)], T=T, control=list(fnscale=-1, pgtol=1e-2),method="L-BFGS-B",lower=0,upper=1000)
		policy <- solution$par[1]
		value <- solution$value
		satval <- V_ss(S_(policy,igrid$sats,igrid$debs),igrid$debs)[1]
		clock <- proc.time()[3] - ctm
		result <- c(igrid$sats[j],igrid$debs[j],policy,satval,value,clock)
		result
	} 
	policy_value <- as.data.frame(policy_value)
	colnames(policy_value) <- c("satellites","debris","launches","sat_value","fleet_value","compute_time")
	avg_time_per_cell <- mean(policy_value$compute_time)
	total_time <- sum(policy_value$compute_time)/(60*60*32)
	print(paste0("Finished. Average time per cell: ", round(avg_time_per_cell,3)," seconds. Total wall time: ", round(total_time,3)," hours."))

	stopImplicitCluster()

	return(policy_value)
}

# Algorithm to calculate a planner's optimal finite-horizon time series.
fp_tsgen <- function(S,D,T,...) {
	ctm <- proc.time()[3]
	parms <- c(rep(0.01,length=T),0,S,D)
	launch_path <- optim(par=parms[1:(T+1)],fn=fhvf, S=parms[(T+2)], D=parms[(T+3)], T=T, control=list(fnscale=-1, pgtol=1e-2),method="L-BFGS-B",lower=0,upper=1000)$par
	launch_path_clock <- proc.time()[3] - ctm

	ctm <- proc.time()[3]
	time_series <- seriesgen_ts(launch_path,S,D,T)
	propagation_clock <- proc.time()[3] - ctm

	print("Fleet planner time series generated.") 
	print(paste0("Time to compute launch path: ", launch_path_clock, " seconds."))
	print(paste0("Time to propagate stocks: ", propagation_clock, " seconds."))

	return(time_series)
}
